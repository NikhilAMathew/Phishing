let proceedURLs = new Set();

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ isEnabled: false, realtimeNotifications: false, blockPhishing: false });
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "updateState") {
    chrome.storage.sync.set({ isEnabled: request.state });
  }

  if (request.action === "proceedToURL") {
    proceedURLs.add(request.url);
  }
});

function showNotification(title, message, url) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/16x16.png',  // Replace with the path to your extension icon
    title: title,
    message: message + '\n\nURL: ' + url,
  });
}


function sendEmail(to, subject, message, url) {
  // Use Email.js service to send an email
  const emailjsParams = {
    user_id: 'Dubs0HKkce-UlORe_',
    service_id: 'service_3wruvfn',
    template_id: 'template_e2rj5vp',
    template_params: {
      to,
      subject,
      message: message + '\n\nURL: ' + url,
    },
  };

  fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(emailjsParams),
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => console.log('Email sent:', data))
    .catch(error => {
      console.error('Error sending email:', error);
      console.log('Email send failed:', error.message);
    });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Ignore about:blank pages
  if (tab.url === 'about:blank') {
    return;
  }

  if (changeInfo.status === 'complete' && tab.url && !tab.url.startsWith('chrome://')  && !tab.url.startsWith('http://127.0.0.1:5000')) {
    chrome.storage.sync.get(['isEnabled', 'blockPhishing', 'realtimeNotifications'], function (data) {
      const isEnabled = data.isEnabled;
      const blockPhishing = data.blockPhishing;
      const realtimeNotifications = data.realtimeNotifications;

      if (isEnabled) {
        if (!tab.url.startsWith(chrome.runtime.getURL("extension/warning.html"))) {
          if (proceedURLs.has(tab.url)) {
            proceedURLs.delete(tab.url);
          } else {
            fetch('http://127.0.0.1:5000/check_url', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ url: tab.url })
            })
            .then(response => response.json())
            .then(data => {
	      if (data.decision === 'PHISHING') {

                if (blockPhishing) {
                const warningPageUrl = chrome.runtime.getURL("extension/warning.html") + "?url=" + encodeURIComponent(tab.url);
                chrome.tabs.update(tabId, { url: warningPageUrl });
		}

                if (realtimeNotifications) {
                  // Show notification
                  showNotification('FindPhish - Phishing Alert', 'This website has been identified as a phishing site.', tab.url);

                  // Send instant email message
                  chrome.storage.sync.get('userEmail', function (userData) {
                    const userEmail = userData.userEmail;
                    if (userEmail) {
                      sendEmail(userEmail, 'Phishing Alert', 'This website has been identified as a phishing site.', tab.url);
                    }
                  });
                }

              }
            })
            .catch(error => console.error('Error:', error));
          }
        }
      }
    });
  }
});
